﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpresaController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;
        public EmpresaController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetEmpresa()
        {
            try
            {
                var lista = _context.Empresas.OrderBy(e => e.EmpresaId).ToList();
                var dto = _mapper.Map<List<EmpresaDTO>>(lista);
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar empresa." + ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetEmpresaId([FromRoute] int id)
        {
            try
            {
                var empresa = _context.Empresas.FirstOrDefault(e => e.EmpresaId == id);
                
                if (empresa == null)
                    return NotFound("Empresa não encontrada.");

                var dto = _mapper.Map<EmpresaDTO>(empresa);

                return Ok(dto);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar empresa." + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult PostEmpresa([FromBody] CreateEmpresaDTO dto)
        {
            try
            {
                var empresa = _mapper.Map<Empresa>(dto);
                _context.Empresas.Add(empresa);
                _context.SaveChanges();
                
                return Ok("Empresa cadastrada com sucesso.");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir o empresa." + ex.Message);
            }
        }

        [HttpPut]
        public IActionResult PutEmpresa([FromBody] EmpresaDTO dto)
        {
            try
            {
                var empresa = _context.Empresas.FirstOrDefault(l => l.EmpresaId == dto.EmpresaId);
                
                if (empresa == null)
                    return NotFound("Empresa não econtrada.");
                {
                    _mapper.Map(dto, empresa);
                    _context.Empresas.Update(empresa);
                    _context.SaveChanges();
                    
                    return Ok("Empresa alterada com sucesso!");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Empresa não alterada." + ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmpresa([FromRoute] int id)
        {
            try
            {
                var empresa = _context.Empresas.FirstOrDefault(l => l.EmpresaId == id);
                
                if (empresa == null)
                    return NotFound("Empresa não encontrada.");
                {
                    _context.Empresas.Remove(empresa);
                    _context.SaveChanges();
                    
                    return Ok("Empresa removida com sucesso.");
                }
            }
            catch(Exception ex)
            {
                return BadRequest("Erro ao excluir a empresa." + ex.Message);
            }
        }
    }
}

