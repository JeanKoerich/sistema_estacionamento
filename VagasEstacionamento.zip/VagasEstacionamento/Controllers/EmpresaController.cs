﻿using Microsoft.AspNetCore.Mvc;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpresaController : ControllerBase
    {
        private readonly AppDbContext _context;
        public EmpresaController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetEmpresa()
        {
            try
            {
                var lista = _context.Empresas
                            .OrderBy(e => e.Empresa_id)
                            .ToList();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar empresa." + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult PostEmpresa(Empresa empresa)
        {
            try
            {
                _context.Empresas.Add(empresa);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir o empresa." + ex.Message);
            }
            return Ok("Empresa cadastrada com sucesso!");
        }

        [HttpPut]
        public IActionResult PutEmpresa(Empresa empresa)
        {
            try
            {
                var exists = _context.Empresas.Where(l => l.Empresa_id == empresa.Empresa_id).FirstOrDefault();
                if (exists != null)
                {
                    exists.Empresa_cnpj = empresa.Empresa_cnpj;
                    _context.Empresas.Update(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return BadRequest("Empresa não encontrada.");
                }
            }
            catch (Exception ex)
            {
                return NotFound("Empresa não alterada." + ex.Message);
            }
            return Ok("Empresa alterada com sucesso!");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmpresa([FromRoute] int id)
        {
            try
            {
                var exists = _context.Empresas.Where(l => l.Empresa_id == id).FirstOrDefault();
                if (exists != null)
                {
                    _context.Empresas.Remove(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return NotFound("Empresa não encontrada.");
                }
            }
            catch(Exception ex)
            {
                return BadRequest("Erro ao excluir a empresa." + ex.Message);
            }
            return Ok("Empresa removido com sucesso.");
        }
    }
}

