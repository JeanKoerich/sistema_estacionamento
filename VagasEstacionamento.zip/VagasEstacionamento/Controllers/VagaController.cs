﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VagaController : ControllerBase
    {
        private readonly AppDbContext _context;

        public VagaController(AppDbContext context)
        {
            _context = context;
        }

        private void AtualizarEstacionamento(int estacionamentoId)
        {
            var estacionamento = _context.Estacionamentos.FirstOrDefault(e => e.Estacionamento_id == estacionamentoId);
            if (estacionamento != null)
            {
                int totalVagas = _context.Vagas.Count(v => v.Estacionamento_ID == estacionamentoId);
                int vagasLivres = _context.Vagas.Count(v => v.Estacionamento_ID == estacionamentoId && v.Disponibilidade == DisponibilidadeVaga.Livre);

                estacionamento.Estacionamento_total_vagas = totalVagas;
                estacionamento.Total_vagas_livre = vagasLivres;

                _context.Estacionamentos.Update(estacionamento);
                _context.SaveChanges();
            }
        }

        [HttpGet]
        public IActionResult GetVaga()
        {
            try
            {
                var lista = _context.Vagas
                            .Include(es => es.Estacionamento)
                            .OrderBy(e => e.Vaga_id)
                            .ToList();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar vaga. " + ex.Message);
            }
        }


        [HttpPost]
        public IActionResult PostVaga(Vaga vaga)
        {
            try
            {
                _context.Vagas.Add(vaga);
                _context.SaveChanges();
                AtualizarEstacionamento(vaga.Estacionamento_ID);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir a vaga." + ex.Message);
            }
            return Ok("Vaga cadastrado com sucesso!");
        }

        [HttpPut]
        public IActionResult PutVaga(Vaga vaga)
        {
            try
            {
                var exists = _context.Vagas.FirstOrDefault(l => l.Vaga_id == vaga.Vaga_id);
                if (exists != null)
                {
                    exists.Vaga_referencia = vaga.Vaga_referencia;
                    exists.Disponibilidade = vaga.Disponibilidade;
                    _context.Vagas.Update(exists);
                    _context.SaveChanges();
                    AtualizarEstacionamento(exists.Estacionamento_ID);
                }
                else
                {
                    return BadRequest("Vaga não encotrada.");
                }
            }
            catch (Exception ex)
            {
                return NotFound("Vaga não alterada." + ex.Message);
            }
            return Ok("Vaga alterado com sucesso!");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteVaga([FromRoute]int id)
        {
            try
            {
                var exists = _context.Vagas.Where(l => l.Vaga_id == id).FirstOrDefault();
                if (exists != null)
                {
                    int estacionamentoId = exists.Estacionamento_ID;
                    _context.Vagas.Remove(exists);
                    _context.SaveChanges();
                    AtualizarEstacionamento(estacionamentoId);
                }
                else
                {
                    return NotFound("Vaga não encontrada.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir a vaga." + ex.Message);
            }
            return Ok("Vaga removido com sucesso.");
        }
    }
}
