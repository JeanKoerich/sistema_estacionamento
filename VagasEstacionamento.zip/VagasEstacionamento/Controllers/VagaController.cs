﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VagaController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public VagaController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        private void AtualizarEstacionamento(int estacionamentoId)
        {
            var estacionamento = _context.Estacionamentos
                .FirstOrDefault(e => e.EstacionamentoId == estacionamentoId);

            if (estacionamento != null)
            {
                int totalVagas = _context.Vagas
                    .Count(v => v.EstacionamentoID == estacionamentoId);
                int vagasLivres = _context.Vagas
                    .Count(v => v.EstacionamentoID == estacionamentoId && v.Disponibilidade == DisponibilidadeVaga.Livre);

                estacionamento.TotalVagas = totalVagas;
                estacionamento.TotalVagasLivres = vagasLivres;

                _context.Estacionamentos.Update(estacionamento);
                _context.SaveChanges();
            }
        }

        [HttpGet]
        public IActionResult GetVaga()
        {
            try
            {
                var vaga = _context.Vagas
                            .Include(es => es.Estacionamento)
                            .OrderBy(e => e.VagaId)
                            .ToList();

                var vagaDTO = _mapper.Map<List<VagaDTO>>(vaga);
                return Ok(vagaDTO);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar vaga. " + ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetVagaId([FromRoute] int id)
        {
            try
            {
                var vaga = _context.Vagas
                            .Include(es => es.Estacionamento)
                            .FirstOrDefault(e => e.VagaId == id);

                if (vaga == null)
                    return NotFound("Vaga não encontrada.");

                var dto = _mapper.Map<VagaDTO>(vaga);
                return Ok(dto);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar vaga. " + ex.Message);
            }
        }


        [HttpPost]
        public IActionResult PostVaga([FromBody] CreateVagaDTO dto)
        {
            try
            {
                var vaga = _mapper.Map<Vaga>(dto);
                _context.Vagas.Add(vaga);
                _context.SaveChanges();
                AtualizarEstacionamento(vaga.EstacionamentoID);

                return Ok("Vaga cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir a vaga." + ex.Message);
            }
        }

        [HttpPut]
        public IActionResult PutVaga(int id, [FromBody] CreateVagaDTO dto)
        {
            try
            {
                var vaga = _context.Vagas.FirstOrDefault(l => l.VagaId == id);
                
                if (vaga == null)
                    return BadRequest("Vaga não encotrada.");


                _mapper.Map(dto, vaga);
                _context.Vagas.Update(vaga);
                _context.SaveChanges();
                AtualizarEstacionamento(vaga.EstacionamentoID);
                return Ok("Vaga alterado com sucesso!");
            }
            catch (Exception ex)
            {
                return NotFound("Vaga não alterada." + ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteVaga([FromRoute]int id)
        {
            try
            {
                var exists = _context.Vagas.FirstOrDefault(l => l.VagaId == id);
                if (exists == null)
                    return NotFound("Vaga não encontrada.");

                int estacionamentoId = exists.EstacionamentoID;
                _context.Vagas.Remove(exists);
                _context.SaveChanges();
                AtualizarEstacionamento(estacionamentoId);
                return Ok("Vaga removido com sucesso.");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir a vaga." + ex.Message);
            }
        }
    }
}
