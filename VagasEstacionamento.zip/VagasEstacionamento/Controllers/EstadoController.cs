﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstadoController : ControllerBase
    {
        private readonly AppDbContext _context;
        
        public EstadoController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetEstado()
        {
            try
            {
                var lista = _context.Estados
                            .Include(emp => emp.Empresa)
                            .OrderBy(e => e.Estado_id)
                            .ToList();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar estado." + ex.Message); 
            }
        }

        [HttpPost]
        public IActionResult PostEstado(Estado estado)
        {
            try
            {
                _context.Add(estado);
                _context.SaveChanges();
                return Ok("Estado cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir Estado: " + ex.Message);
                throw;
            }
        }

        [HttpPut]
        public IActionResult PutEstado(Estado estado)
        {
            try
            {
                var exists = _context.Estados.Where(l => l.Estado_id == estado.Estado_id).FirstOrDefault();
                if (exists != null)
                {
                    exists.Estado_nome = estado.Estado_nome;
                    _context.Estados.Update(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return BadRequest("Estado não encotrado.");
                }
            }
            catch (Exception ex)
            {
                return NotFound("Estado não alterada." + ex.Message);
            }
            return Ok("Estado alterado com sucesso!");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstado([FromRoute] int id)
        {
            try
            {
                var exists = _context.Estados.Where(l => l.Estado_id == id).FirstOrDefault();
                if (exists != null)
                {
                    _context.Estados.Remove(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return NotFound("Estado não encontrada.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir a Estado." + ex.Message);
            }
            return Ok("Estado removido com sucesso.");
        }
    }
}
