﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstadoController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public EstadoController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetEstado()
        {
            try
            {
                var lista = _context.Estados
                            .Include(emp => emp.Empresa)
                            .OrderBy(e => e.EstadoId)
                            .ToList();

                var dto = _mapper.Map<List<EstadoDTO>>(lista);
                return Ok(dto);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar estado." + ex.Message); 
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetEstadoId([FromRoute] int id)
        {
            try
            {
                var estado = _context.Estados
                    .Include(emp => emp.Empresa)
                    .FirstOrDefault(e => e.EstadoId == id);
                
                if (estado == null)
                    return NotFound("Estado não encontrado.");

                var dto = _mapper.Map<EstadoDTO>(estado);
                return Ok(dto);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar estado." + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult PostEstado([FromBody] CreateEstadoDTO dto)
        {
            try
            {
                var estado = _mapper.Map<Estado>(dto);
                _context.Add(estado);
                _context.SaveChanges();
                return Ok("Estado cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir Estado: " + ex.Message);
            }
        }

        [HttpPut]
        public IActionResult PutEstado([FromBody] EstadoDTO dto)
        {
            try
            {
                var estado = _context.Estados.FirstOrDefault(l => l.EstadoId == dto.EstadoId);
                if (estado == null)
                    return BadRequest("Estado não encotrado.");

                _mapper.Map(dto, estado);
                estado.Nome = estado.Nome;
                _context.Estados.Update(estado);
                _context.SaveChanges();
                return Ok("Estado alterado com sucesso!");
            }
            catch (Exception ex)
            {
                return NotFound("Estado não alterada." + ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstado([FromRoute] int id)
        {
            try
            {
                var estado = _context.Estados.FirstOrDefault(l => l.EstadoId == id);
                if (estado == null)
                    return NotFound("Estado não encontrado.");

                _context.Estados.Remove(estado);
                _context.SaveChanges();
                return Ok("Estado removido com sucesso.");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir a Estado." + ex.Message);

            }
        }
    }
}
