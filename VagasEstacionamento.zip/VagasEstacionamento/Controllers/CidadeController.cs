﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CidadeController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public CidadeController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetCidade()
        {
            try
            {
                var lista = _context.Cidades
                            .Include(est => est.Estado)
                                .ThenInclude(emp => emp.Empresa)
                            .OrderBy(cid => cid.CidadeId)
                            .ToList();

                var dto = _mapper.Map<List<CidadeDTO>>(lista);
                return Ok(dto);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar cidade. " + ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetCidadeId([FromRoute] int id)
        {
            try
            {
                var cidade = _context.Cidades
                            .Include(est => est.Estado)
                                .ThenInclude(emp => emp.Empresa)
                            .FirstOrDefault(cid => cid.CidadeId == id);

                if (cidade == null)
                    return NotFound("Cidade não encontrada.");

                var dto = _mapper.Map<CidadeDTO>(cidade);
                return Ok(dto);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar cidade. " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult PostCidade([FromBody] CreateCidadeDTO dto)
        {
            try
            {
                var cidade = _mapper.Map<Cidade>(dto);
                _context.Cidades.Add(cidade);
                _context.SaveChanges();
                return Ok("Cidade cadastrada com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir a cidade. " + ex.Message);
            }
        }

        [HttpPut]
        public IActionResult PutCidade([FromBody] CidadeDTO dto)
        {
            try
            {
                var cidade = _context.Cidades.FirstOrDefault(c => c.CidadeId == dto.CidadeId);
                if (cidade == null)
                    return NotFound("Cidade não encontrada.");

                _mapper.Map(dto, cidade);
                _context.Cidades.Update(cidade);
                _context.SaveChanges();
                return Ok("Cidade alterada com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Cidade não alterada. " + ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCidade([FromRoute] int id)
        {
            try
            {
                var cidade = _context.Cidades.FirstOrDefault(c => c.CidadeId == id);
                if (cidade == null)
                    return NotFound("Cidade não encontrada.");

                _context.Cidades.Remove(cidade);
                _context.SaveChanges();
                return Ok("Cidade removida com sucesso.");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir a cidade. " + ex.Message);
            }
        }
    }
}
