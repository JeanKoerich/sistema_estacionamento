﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CidadeController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CidadeController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetCidade()
        {
            try
            {
                var lista = _context.Cidades
                            .Include(est => est.Estado)
                                .ThenInclude(emp => emp.Empresa)
                            .OrderBy(e => e.Cidade_id)
                            .ToList();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar cidade." + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult PostCidade(Cidade cidade)
        {
            try
            {
                _context.Add(cidade);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir a cidade." + ex.Message);
            }
            return Ok("Cidade cadastrada com sucesso!");
        }

        [HttpPut]
        public IActionResult PutCidade(Cidade cidade)
        {
            try
            {
                var exists = _context.Cidades.Where(l => l.Cidade_id == cidade.Cidade_id).FirstOrDefault();
                if (exists != null)
                {
                    exists.Cidade_nome = cidade.Cidade_nome;
                    _context.Cidades.Update(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return BadRequest("Cidade não encontrada.");
                }
            }
            catch (Exception ex)
            {
                return NotFound("Cidade não alterada." + ex.Message);
            }
            return Ok("Vaga alterada com sucesso!");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCidade([FromRoute] int id)
        { 
            try
            {
                var exists = _context.Cidades.Where(l => l.Cidade_id == id).FirstOrDefault();
                if (exists != null)
                {
                    _context.Cidades.Remove(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return NotFound("Cidade não encontrada.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir a cidade." + ex.Message);
            }
            return Ok("Cidade removida com sucesso.");
        }
    }
}
