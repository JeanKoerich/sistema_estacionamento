﻿using System.Linq.Expressions;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstacionamentoController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;
        public EstacionamentoController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetEstacionamento()
        {
            try
            {
                var estacionamento = _context.Estacionamentos
                            .Include(cid => cid.Cidade)
                                .ThenInclude(est => est.Estado)
                                    .ThenInclude(emp => emp.Empresa)
                            .ToList();

                var estacionamentoDTO = _mapper.Map<List<EstacionamentoDTO>>(estacionamento);
                return Ok(estacionamentoDTO);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar Estacionamento." + ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetEstacionamentoId([FromRoute] int id)
        {
            try
            {
                var estacionamento = _context.Estacionamentos
                            .Include(cid => cid.Cidade)
                                .ThenInclude(est => est.Estado)
                                    .ThenInclude(emp => emp.Empresa)
                            .FirstOrDefault(e => e.EstacionamentoId == id);

                if (estacionamento == null)
                    return NotFound("Estacionamento não encontrado.");

                var estacionamentoDTO = _mapper.Map<EstacionamentoDTO>(estacionamento);
                return Ok(estacionamentoDTO);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar Estacionamento." + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult PostEstacionamento([FromBody] CreateEstacionamentoDTO dto)
        {
            try
            {
                var estacionamento = _mapper.Map<Estacionamento>(dto);

                _context.Estacionamentos.Add(estacionamento);
                _context.SaveChanges();

                // Recalcula Vagas Livres
                int totalVagasLivres = _context.Vagas
                    .Count(v => v.EstacionamentoID == estacionamento.EstacionamentoId &&
                                v.Disponibilidade == DisponibilidadeVaga.Livre);

                
                _context.Estacionamentos.Update(estacionamento);
                _context.SaveChanges();
                return Ok("Estacionamento cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir o estacionamento." + ex.Message);
            }
        }

        [HttpPut]
        public IActionResult PutEstacionamento([FromBody] EstacionamentoDTO dto)
        {
            try
            {
                var estacionamento = _context.Estacionamentos
                    .FirstOrDefault(l => l.EstacionamentoId == dto.EstacionamentoId);

                if (estacionamento == null)
                    return BadRequest("Estacionamento não encontrado.");

                estacionamento.Nome = dto.Nome;
                estacionamento.Endereco = dto.Endereco;
                estacionamento.CEP = dto.CEP;
                estacionamento.Telefone = dto.Telefone;
                estacionamento.EmailContato = dto.EmailContato;
                estacionamento.TotalVagas = dto.TotalVagas;
                estacionamento.CidadeID = dto.CidadeID;
                estacionamento.EmpresaID = dto.EmpresaID;

                // Recalcula vagas livres
                estacionamento.TotalVagasLivres = _context.Vagas
                    .Count(v => v.EstacionamentoID == estacionamento.EstacionamentoId &&
                                v.Disponibilidade == DisponibilidadeVaga.Livre);

                _context.Estacionamentos.Update(estacionamento);
                _context.SaveChanges();
                return Ok("Estacionamento alterado com sucesso!");
            }            
            catch(Exception ex)
            {
                return NotFound("Estacionamento não alterado." + ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstacionamento([FromRoute] int id)
        {
            try
            {
                var estacionamento = _context.Estacionamentos.
                    FirstOrDefault(l => l.EstacionamentoId == id);

                if (estacionamento == null)
                    return NotFound("Estacionamento não encontrado.");

                _context.Estacionamentos.Remove(estacionamento);
                _context.SaveChanges();
                return Ok("Estacionamento removido com sucesso.");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir o estacionamento." + ex.Message);
            }
        }
    }
}
