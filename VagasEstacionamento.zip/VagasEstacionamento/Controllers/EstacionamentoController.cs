﻿using System.Linq.Expressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Data;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstacionamentoController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EstacionamentoController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetEstacionamento()
        {
            try
            {
                var lista = _context.Estacionamentos
                            .Include(cid => cid.Cidade)
                                .ThenInclude(est => est.Estado)
                                    .ThenInclude(emp => emp.Empresa)
                            .OrderBy(e => e.Estacionamento_id)
                            .ToList();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao consultar Estacionamento." + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult PostEstacionamento(Estacionamento estacionamento)
        {
            try
            {
                _context.Add(estacionamento);
                _context.SaveChanges();

                // Agora calcula as vagas livres vinculadas ao ID recém-criado
                int totalVagasLivres = _context.Vagas
                    .Count(v => v.Estacionamento_ID == estacionamento.Estacionamento_id &&
                                v.Disponibilidade == DisponibilidadeVaga.Livre);

                // Atualiza o total
                estacionamento.Estacionamento_total_vagas = totalVagasLivres;
                _context.Estacionamentos.Update(estacionamento);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir o estacionamento." + ex.Message);
            }
            return Ok("Estacionamento cadastrado com sucesso!");
        }

        [HttpPut]
        public IActionResult PutEstacionamento(Estacionamento estacionamento)
        {
            try
            {
                var exists = _context.Estacionamentos.Where(l => l.Estacionamento_id == estacionamento.Estacionamento_id).FirstOrDefault();
                if (exists != null)
                {
                    exists.Estacionamento_nome = estacionamento.Estacionamento_nome;

                    // Recalcula vagas livres para esse estacionamento
                    int totalVagasLivres = _context.Vagas
                        .Count(v => v.Estacionamento_ID == estacionamento.Estacionamento_id &&
                                    v.Disponibilidade == DisponibilidadeVaga.Livre);

                    exists.Total_vagas_livre = totalVagasLivres;

                    _context.Estacionamentos.Update(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return BadRequest("Estacionamento não encontrado.");
                }
            }            
            catch(Exception ex)
            {
                return NotFound("Estacionamento não alterado." + ex.Message);
            }
            return Ok("Estacionamento alterado com sucesso!");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstacionamento([FromRoute] int id)
        {
            try
            {
                var exists = _context.Estacionamentos.Where(l => l.Estacionamento_id == id).FirstOrDefault();
                if (exists != null)
                {
                    _context.Estacionamentos.Remove(exists);
                    _context.SaveChanges();
                }
                else
                {
                    return NotFound("Estacionamento não encontrado.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir o estacionamento." + ex.Message);
            }
            return Ok("Estacionamento removido com sucesso.");
        }
    }
}
