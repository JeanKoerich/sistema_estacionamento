﻿using Microsoft.EntityFrameworkCore;
using VagasEstacionamento.Model;

namespace VagasEstacionamento.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Empresa> Empresas { get; set; }
        public DbSet<Estado> Estados { get; set; }

        public DbSet<Cidade> Cidades { get; set; }
        public DbSet<Estacionamento> Estacionamentos { get; set; }
        public DbSet<Vaga> Vagas { get; set; }

        internal object Include(Func<object, object> value)
        {
            throw new NotImplementedException();
        }
    }
}

