﻿using ConFinSever.Model;
using Microsoft.EntityFrameworkCore;

namespace VagasEstacionamento.Data
{
    public class DbContext : DbContext
    {
        public DbContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Vaga> Vagas { get; set; }
    }
}
