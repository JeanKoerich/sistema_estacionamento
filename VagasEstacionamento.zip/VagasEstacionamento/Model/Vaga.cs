﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VagasEstacionamento.Model
{
    public class Vaga
    {
        [Key]
        [Display(Name = "ID de Vaga")]
        public int Vaga_id { get; set; }

        [Required(ErrorMessage = "Referencia é obrigatório")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Referencia deve possuir entre 1 a 100 caracteres")]
        [Display(Name = "Referencia")]
        public string Vaga_referencia { get; set; }

        [Required(ErrorMessage = "Disponibilidade é obrigatório")]
        [Display(Name = "Disponibilidade")]
        public DisponibilidadeVaga Disponibilidade { get; set; } = DisponibilidadeVaga.Livre;

        [ForeignKey("Estacionamento_ID")]
        public int Estacionamento_ID { get; set; }
        public Estacionamento? Estacionamento { get; set; }
    }
}