﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VagasEstacionamento.Model
{
    public class Vaga
    {
        [Key]
        [Display(Name = "ID de Vaga")]
        public int VagaId {get; set;}

        [Required(ErrorMessage = "Referencia é obrigatório")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Referencia deve possuir entre 1 a 100 caracteres")]
        [Display(Name = "Referencia")]
        public string Referencia {get; set;}

        [Required(ErrorMessage = "Disponibilidade é obrigatório")]
        [Display(Name = "Disponibilidade")]
        public DisponibilidadeVaga Disponibilidade {get; set;} = DisponibilidadeVaga.Livre;

        [Display(Name = "Tipo de Vaga")]
        public TipoVaga Tipo {get; set;} = TipoVaga.Carro;

        [Display(Name = "Ultima Atualização")]

        [ForeignKey("EstacionamentoID")]
        public int EstacionamentoID {get; set;}
        public Estacionamento? Estacionamento {get; set;}
    }
    public class VagaDTO
    {
        public int VagaId { get; set; }
        public string Referencia { get; set; }
        public DisponibilidadeVaga Disponibilidade { get; set; }
        public TipoVaga Tipo { get; set; }
        public int EstacionamentoID { get; set; }
    }

    public class CreateVagaDTO
    {
        [Required(ErrorMessage = "Referencia é obrigatória")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Referencia deve possuir entre 1 a 100 caracteres")]
        public string Referencia { get; set; }

        [Required(ErrorMessage = "Disponibilidade é obrigatória")]
        public DisponibilidadeVaga Disponibilidade { get; set; } = DisponibilidadeVaga.Livre;

        public TipoVaga Tipo { get; set; } = TipoVaga.Carro;

        [Required(ErrorMessage = "EstacionamentoID é obrigatório")]
        public int EstacionamentoID { get; set; }
    }
}