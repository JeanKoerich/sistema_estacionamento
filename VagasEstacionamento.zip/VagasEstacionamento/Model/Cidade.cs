﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VagasEstacionamento.Model
{
    public class Cidade
    {
        [Key]

        [Display(Name = "ID da Cidade")]
        public int CidadeId {get; set;}

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100)]
        [Display(Name = "Nome da cidade")]
        public string Nome {get; set;}

        [StringLength(10)]
        public string? CodigoIBGE {get; set;}

        public ICollection<Estacionamento>? Estacionamentos {get; set;}

        [Required]
        public int EstadoID {get; set;}
        public Estado? Estado {get; set;}
    }

    public class CidadeDTO
    {
        public int CidadeId { get; set; }
        public string Nome { get; set; }
        public string? CodigoIBGE { get; set; }

        public int EstadoID { get; set; }
        public int EmpresaID { get; set; }
    }

    public class CreateCidadeDTO
    {
        public string Nome { get; set; }
        public string? CodigoIBGE { get; set; }
        public int EstadoID { get; set; }
    }
}
