﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VagasEstacionamento.Model
{
    public class Cidade
    {
        [Key]

        [Display(Name = "ID da Cidade")]
        public int Cidade_id { get; set; }

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Nome deve possuir entre 1 a 100 caracteres")]
        [Display(Name = "Nome da cidade")]
        public string Cidade_nome { get; set; }

        [Required]
        public int Estado_ID { get; set; }
        public Estado? Estado { get; set; }
    }
}
