﻿using AutoMapper;

namespace VagasEstacionamento.Model
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Empresa, EmpresaDTO>().ReverseMap();
            CreateMap<Empresa, CreateEmpresaDTO>().ReverseMap();

            CreateMap<Estado, EstadoDTO>().ReverseMap();
            CreateMap<Estado, CreateEstadoDTO>().ReverseMap();

            CreateMap<Cidade, CidadeDTO>()
                .ForMember(dest => dest.EmpresaID, opt => opt.MapFrom(src => src.Estado.Empresa.EmpresaId));
            CreateMap<Cidade, CreateCidadeDTO>().ReverseMap();
            
            CreateMap<Estacionamento, EstacionamentoDTO>()
                .ForMember(dest => dest.EmpresaID, opt => opt.MapFrom(src => src.Cidade.Estado.Empresa.EmpresaId));
            CreateMap<Estacionamento, CreateEstacionamentoDTO>().ReverseMap();

            CreateMap<Vaga, VagaDTO>().ReverseMap();
            CreateMap<Vaga, CreateVagaDTO>().ReverseMap();
        }
    }
}
