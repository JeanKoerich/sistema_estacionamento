﻿namespace VagasEstacionamento.Model
{
    public enum DisponibilidadeVaga
    {
        Livre = 0,
        Ocupado = 1
    }
}
