﻿namespace VagasEstacionamento.Model
{
    public enum TipoVaga
    {
        Carro = 0,
        PCD = 1,
        Idoso = 2,
        Moto = 3
    }
}
