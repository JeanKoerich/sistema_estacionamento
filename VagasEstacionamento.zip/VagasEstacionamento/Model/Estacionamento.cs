﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VagasEstacionamento.Model
{
    public class Estacionamento
    {
        [Key]

        [Display(Name = "ID do Estacionamento")]
        public int Estacionamento_id { get; set; }

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Nome deve possuir entre 1 a 100 caracteres")]
        [Display(Name = "Nome do Estacionamento")]
        public string Estacionamento_nome { get; set; }

        [Display(Name = "Total de vagas")]
        public int Estacionamento_total_vagas { get; set; }

        [Display(Name = "Total de vagas livres")]
        public int Total_vagas_livre { get; set; }

        public ICollection <Vaga> Vagas { get; set;}
        
        [Required]
        public int Cidade_ID { get; set; }
        public Cidade? Cidade { get; set; }
    }
}
