﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc;

namespace VagasEstacionamento.Model
{
    public class Estacionamento
    {
        [Key]

        [Display(Name = "ID do Estacionamento")]
        public int EstacionamentoId {get; set;}

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100)]
        [Display(Name = "Nome do Estacionamento")]
        public string Nome {get; set;}

        [Display(Name = "Total de vagas")]
        public int TotalVagas {get; set;}

        [Display(Name = "Total de vagas livres")]
        public int TotalVagasLivres {get; set;}

        [StringLength(200)]
        public string? Endereco {get; set;}

        [StringLength(20)]
        public string? CEP {get; set;}

        [StringLength(20)]
        public string? Telefone {get; set;}

        [EmailAddress]
        public string? EmailContato {get; set;}

        public ICollection <Vaga> Vagas {get; set;}
        
        [Required]
        public int CidadeID {get; set;}
        public Cidade? Cidade {get; set;}

        [Required]
        public int EmpresaID {get; set;}
        public Empresa? Empresa { get; set;}
    }

    public class EstacionamentoDTO
    {
        public int EstacionamentoId { get; set; }
        public string Nome { get; set; }
        public int TotalVagas { get; set; }
        public int TotalVagasLivres { get; set; }
        public string? Endereco { get; set; }
        public string? CEP { get; set; }
        public string? Telefone { get; set; }
        public string? EmailContato { get; set; }

        public int CidadeID { get; set; }
        public int EmpresaID { get; set; }
    }

    public class CreateEstacionamentoDTO
    {
        public string Nome { get; set; }
        public int TotalVagas { get; set; }
        public int TotalVagasLivres { get; set; }
        public string? Endereco { get; set; }
        public string? CEP { get; set; }
        public string? Telefone { get; set; }
        public string? EmailContato { get; set; }

        public int CidadeID { get; set; }
        public int EmpresaID { get; set; }
    }
}
