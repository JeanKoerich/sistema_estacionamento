﻿using System.ComponentModel.DataAnnotations;

namespace VagasEstacionamento.Model
{
    public class Empresa
    {
        [Key]
        [Display(Name = "ID da Empresa")]
        public int Empresa_id { get; set; }

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Nome deve possuir entre 1 a 100 caracteres")]
        [Display(Name = "Nome do Empresa")]
        public string Empresa_nome { get; set; }

        [Required(ErrorMessage = "CNPJ é obrigatório")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "CNPJ deve possuir no máximo 14 caracteres")]
        [Display(Name = "CNPJ da Empresa")]
        public string Empresa_cnpj { get; set; }
    }
}
