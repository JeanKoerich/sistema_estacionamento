﻿using System.ComponentModel.DataAnnotations;

namespace VagasEstacionamento.Model
{
    public class Empresa
    {
        [Key]
        [Display(Name = "ID da Empresa")]
        public int EmpresaId {get; set;}

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100)]
        [Display(Name = "Nome do Empresa")]
        public string Nome {get; set;}

        [Required(ErrorMessage = "CNPJ é obrigatório")]
        [StringLength(18, MinimumLength = 14, ErrorMessage = "CNPJ deve possuir no máximo 14 a 18 caracteres")]
        [Display(Name = "CNPJ da Empresa")]
        public string Cnpj {get; set;}
        
        [EmailAddress]
        public string? Email {get; set;}

        [StringLength(20)]
        public string? Telefone {get; set;}

        [Display(Name = "Data de Cadastro")]
        public DateTime DataCadastro {get; set;} = DateTime.UtcNow;

        public ICollection<Estado>? Estados {get; set;}
    }

    public class EmpresaDTO
    {
        public int EmpresaId { get; set; }
        public string Nome { get; set; }
        public string Cnpj { get; set; }
        public string? Email { get; set; }
        public string? Telefone { get; set; }
    }

    public class CreateEmpresaDTO
    {
        public string Nome { get; set; }
        public string Cnpj { get; set; }
        public string? Email { get; set; }
        public string? Telefone { get; set; }
    }
}
