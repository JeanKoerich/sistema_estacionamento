﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VagasEstacionamento.Model
{
    public class Estado
    {
        [Key]

        [Display(Name = "ID da Estado")]
        public int Estado_id { get; set; }

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Nome deve possuir entre 1 a 100 caracteres")]
        [Display(Name = "Nome do Estado")]
        public string Estado_nome { get; set; }

        [Required]
        public int Empresa_ID { get; set; }
        public  Empresa? Empresa { get; set; }
    }
}
