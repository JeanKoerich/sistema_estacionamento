﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VagasEstacionamento.Model
{
    public class Estado
    {
        [Key]

        [Display(Name = "ID da Estado")]
        public int EstadoId {get; set;}

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100)]
        [Display(Name = "Nome do Estado")]
        public string Nome {get; set;}
        
        [Required]
        [StringLength(2)]
        [Display(Name = "UF")]
        public string UF {get; set;}
        public ICollection<Cidade>? Cidades { get; set; }

        [Required]
        public int EmpresaID {get; set;}
        public  Empresa? Empresa {get; set;}
    }

    public class EstadoDTO
    {
        public int EstadoId { get; set; }
        public string Nome { get; set; }
        public string UF { get; set; }
        public int EmpresaID { get; set; }
    }

    public class CreateEstadoDTO
    {
        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100)]
        public string Nome { get; set; }

        [Required]
        [StringLength(2)]
        public string UF { get; set; }

        [Required]
        public int EmpresaID { get; set; }
    }
}
