﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace VagasEstacionamento.Migrations
{
    /// <inheritdoc />
    public partial class sistema_estacionamento : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Empresas",
                columns: table => new
                {
                    Empresa_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Empresa_nome = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Empresa_cnpj = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Empresas", x => x.Empresa_id);
                });

            migrationBuilder.CreateTable(
                name: "Estados",
                columns: table => new
                {
                    Estado_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Estado_nome = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Empresa_ID = table.Column<int>(type: "integer", nullable: false),
                    Empresa_id = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Estados", x => x.Estado_id);
                    table.ForeignKey(
                        name: "FK_Estados_Empresas_Empresa_id",
                        column: x => x.Empresa_id,
                        principalTable: "Empresas",
                        principalColumn: "Empresa_id");
                });

            migrationBuilder.CreateTable(
                name: "Cidades",
                columns: table => new
                {
                    Cidade_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Cidade_nome = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Estado_ID = table.Column<int>(type: "integer", nullable: false),
                    Estado_id = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cidades", x => x.Cidade_id);
                    table.ForeignKey(
                        name: "FK_Cidades_Estados_Estado_id",
                        column: x => x.Estado_id,
                        principalTable: "Estados",
                        principalColumn: "Estado_id");
                });

            migrationBuilder.CreateTable(
                name: "Estacionamentos",
                columns: table => new
                {
                    Estacionamento_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Estacionamento_nome = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Estacionamento_total_vagas = table.Column<int>(type: "integer", nullable: false),
                    Total_vagas_livre = table.Column<int>(type: "integer", nullable: false),
                    Cidade_ID = table.Column<int>(type: "integer", nullable: false),
                    Cidade_id = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Estacionamentos", x => x.Estacionamento_id);
                    table.ForeignKey(
                        name: "FK_Estacionamentos_Cidades_Cidade_id",
                        column: x => x.Cidade_id,
                        principalTable: "Cidades",
                        principalColumn: "Cidade_id");
                });

            migrationBuilder.CreateTable(
                name: "Vagas",
                columns: table => new
                {
                    Vaga_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Vaga_referencia = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Disponibilidade = table.Column<int>(type: "integer", nullable: false),
                    Estacionamento_ID = table.Column<int>(type: "integer", nullable: false),
                    Estacionamento_id = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vagas", x => x.Vaga_id);
                    table.ForeignKey(
                        name: "FK_Vagas_Estacionamentos_Estacionamento_id",
                        column: x => x.Estacionamento_id,
                        principalTable: "Estacionamentos",
                        principalColumn: "Estacionamento_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cidades_Estado_id",
                table: "Cidades",
                column: "Estado_id");

            migrationBuilder.CreateIndex(
                name: "IX_Estacionamentos_Cidade_id",
                table: "Estacionamentos",
                column: "Cidade_id");

            migrationBuilder.CreateIndex(
                name: "IX_Estados_Empresa_id",
                table: "Estados",
                column: "Empresa_id");

            migrationBuilder.CreateIndex(
                name: "IX_Vagas_Estacionamento_id",
                table: "Vagas",
                column: "Estacionamento_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Vagas");

            migrationBuilder.DropTable(
                name: "Estacionamentos");

            migrationBuilder.DropTable(
                name: "Cidades");

            migrationBuilder.DropTable(
                name: "Estados");

            migrationBuilder.DropTable(
                name: "Empresas");
        }
    }
}
